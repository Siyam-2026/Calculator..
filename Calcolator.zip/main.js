function ClearAll() {
  document.getElementById('MyResult').value = '';
  document.getElementById('Result').value = '';
}

function calcolator(value) {
  document.getElementById('MyResult').value += value;
}

function Answer() {
  let a = document.getElementById('MyResult').value;
  if (a !== '') {
    document.getElementById('Result').value = eval(a);
  }
}

// ⌫ এক সংখ্যা কাটার বাটন
function backspace() {
  let x = document.getElementById('MyResult').value;
  document.getElementById('MyResult').value = x.slice(0, -1);
}